"use client";
import { useState } from "react";
import useSWR from "swr";
import { getInboundEmails, tenantRequest } from "@/lib/api";
import EmptyState from "@/components/EmptyState";
import { SkeletonCard } from "@/components/Skeleton";
import { formatFileSize } from "@/lib/utils";
import { useTranslation } from "@/lib/i18n";

type Attachment = {
  attachment_id: string;
  filename: string;
  size_bytes: number;
  status: string;
  attempt: number;
  receipt_id?: string | null;
  error_code?: string | null;
};

type Email = {
  email_id: string;
  sender: string;
  subject: string;
  status: string;
  attachments: Attachment[];
};

export default function InboxPage() {
  const { t } = useTranslation();
  const { data, error, isLoading, mutate } = useSWR<{ items: Email[]; address: string }>(
    "/product/inbound-emails",
    getInboundEmails as never,
  );
  const [retrying, setRetrying] = useState("");

  async function retry(email: string, attachment: string) {
    setRetrying(attachment);
    try {
      await tenantRequest(`/product/inbound-emails/${email}/attachments/${attachment}/retry`, {
        method: "POST",
        body: "{}",
      });
      await mutate();
    } finally {
      setRetrying("");
    }
  }

  return (
    <main className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{t("inbox")}</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          {t("inboxForwardPrefix")} <strong>{data?.address ?? "your family inbox address"}</strong>. {t("inboxForwardSuffix")}
        </p>
      </div>
      {isLoading ? (
        <SkeletonCard className="h-48" />
      ) : error ? (
        <div role="alert" className="card border-red-200 dark:border-red-900/50 p-5">
          <h2 className="font-semibold text-red-800 dark:text-red-200">{t("couldNotLoad")}</h2>
          <button className="btn-primary mt-3" onClick={() => mutate()}>
            Retry
          </button>
        </div>
      ) : !data?.items.length ? (
        <EmptyState
          icon="📧"
          title="No emails received"
          description={t("inboxEmptyDesc")}
        />
      ) : (
        <ul className="space-y-4" aria-label="Inbound emails">
          {data.items.map((email) => (
            <li className="card p-5" key={email.email_id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{email.subject}</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400">{t("fromLabel")} {email.sender}</p>
                </div>
                <span className="rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1 text-xs font-semibold">
                  {email.status}
                </span>
              </div>
              <ul className="mt-4 space-y-2">
                {email.attachments.map((a) => (
                  <li className="rounded-lg border border-slate-200 dark:border-slate-700 p-3" key={a.attachment_id}>
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="font-medium">{a.filename}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {formatFileSize(a.size_bytes)} · attempt {a.attempt} · {a.status}
                        </p>
                        {a.error_code && (
                          <p className="mt-1 text-xs text-red-700 dark:text-red-300">{a.error_code}</p>
                        )}
                      </div>
                      {a.status === "failed" && (
                        <button
                          className="btn-primary text-sm"
                          disabled={retrying === a.attachment_id}
                          onClick={() => retry(email.email_id, a.attachment_id)}
                        >
                          {retrying === a.attachment_id ? t("retryingLabel") : t("retry")}
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
