# Product workflows

ReceiptLens now exposes a human-facing workspace and a tenant-aware product API in addition to the legacy OCR endpoints.

## Start the application

```bash
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/workspace` to upload a receipt. The workspace submits the image to the product workflow and displays the structured result.

## Tenant and role context

Product endpoints accept these headers:

```text
X-Tenant-ID: your-workspace
X-Role: admin | reviewer | integrator
```

The default `demo`/`admin` context preserves local-development compatibility. Production deployments must inject authenticated header values at a trusted gateway or replace the dependency with an identity-provider adapter. Client-supplied identity headers must not be trusted directly on an internet-facing deployment.

## Persistence

Set `RECEIPTLENS_PRODUCT_DB` to a writable SQLite path:

```bash
export RECEIPTLENS_PRODUCT_DB=./receiptlens-product.db
```

Without the variable, the product service uses an in-memory database suitable for tests and demonstrations. Production deployments should use a mounted persistent path or replace the adapter through the `ProductService` boundary.

## Product endpoints

- `POST /product/receipts/upload`: process and store a receipt.
- `GET /product/jobs`: tenant-scoped processing history.
- `POST /product/jobs/{job_id}/retry`: idempotent retry metadata operation.
- `POST /product/jobs/{job_id}/cancel`: cancel a cancellable job.
- `GET /product/review-items`: list low-confidence receipts.
- `PATCH /product/review-items/{receipt_id}`: version-checked correction.
- `POST /product/members`: add a workspace member.
- `POST /product/api-keys`: create a one-time visible API secret.
- `POST /product/connections`: configure CSV, QuickBooks, or Xero mapping metadata.
- `POST /product/connections/{connection_id}/test`: validate a connection definition.
- `POST /product/exports`: create a tenant-scoped export record.
- `GET /product/dashboard`: return usage, quality, privacy, and service summaries.

## Security notes

- Every product query scopes data by tenant.
- Review changes use the `If-Match` version header and return HTTP 409 for stale updates.
- API key secrets are returned only when created; only a SHA-256 digest is stored.
- Audit events contain identifiers and actions, not receipt bodies or secrets.
- The existing upload MIME and OCR validation remains active for real requests.

## Market features in v0.7.0

- `GET /product/receipts`: search by `query`, `status`, `tag`, `min_total`, and `max_total`; pagination uses `limit` and `offset`.
- `PUT /product/receipts/{receipt_id}/metadata`: set up to 20 tags plus optional `project` and `cost_center`.
- `POST /product/approval-policies`: create an admin-only currency threshold policy.
- `POST /product/receipts/{receipt_id}/approval`: evaluate a receipt and create a pending approval when required.
- `POST /product/approvals/{approval_id}/decision`: reviewer/admin approval or rejection with an optional note.
- `PUT /product/privacy/retention`: set retention from 1 to 3,650 days.
- `POST /product/privacy/purge`: remove expired tenant data and dependent rows transactionally.
- `GET /product/privacy/export`: export versioned tenant JSON with receipt metadata and approvals.

All operations are tenant-scoped. Approval policy and retention changes require `admin`; decisions require `admin` or `reviewer`. See `docs/research/MARKET_RESEARCH_2026.md` for the evidence, specifications, roadmap, and validation plan.

## Daily workflow improvements in v1.3.0

### Precise task links

`GET /product/work-queue` now returns action URLs that preserve the exact work context:

- review: `#review?receipt={receipt_id}`;
- export blocker: `#receipts?receipt={receipt_id}&field={field}`;
- approval: `#approvals?approval={approval_id}`.

The workspace consumes the complete action URL, loads the relevant view, selects the identified record, and moves focus to the repair or decision context. Existing hash-only routes remain valid.

### Accessible business-action dialogs

The workspace no longer uses browser `prompt()` or `confirm()` for approval decisions, API-key naming, saved-view naming, or retention purge. Shared dialog behavior now provides:

- explanatory consequence text;
- initial focus;
- inline validation through a live error element;
- required rejection reason;
- typed `TÖRLÉS` confirmation before irreversible purge;
- explicit cancel and confirm actions.

The browser's PWA installation prompt remains unchanged because it is a platform installation API, not a ReceiptLens business-action prompt.

## Exception-to-export workflow

Use Review filters to isolate low-confidence receipts, correct data with the current receipt version, then create an export preparation. Preparations are immutable snapshots. Warning receipts require explicit acknowledgement. Reusing an `Idempotency-Key` returns the original export run and never duplicates the CSV artifact.

## Safe automation workflow

Create a draft rule, preview matching receipts, activate the previewed version, and run it over an explicit receipt set. Run items record versions. Rollback preview separates eligible receipts from conflicts created by later edits; rollback changes only eligible receipts.

## Attachment-level Inbox recovery

Each inbound attachment is validated independently. Valid receipt images complete, unsupported or mismatched files are quarantined, PDF files explicitly report unavailable processing, and OCR failures remain retryable. The email becomes completed, partial, failed, quarantined, or processing based on its children.

## Automation conflicts and rollback

Preview compares matching active rules at the target-field level. Lower numeric priority wins; ties use creation time and then rule ID. Rollback preflight excludes later-edited receipts, and execution is a single SQLite transaction so injected failures persist no partial reversal.

## Verified exception-to-export contract

The review, quality, inbox, automation, and export flows are tenant-scoped and version-aware. `GET /product/review-items` supports confidence field/threshold filtering and ordering. Quality benchmark reports and active profiles are available under `/product/quality`. Email attachment status and retry are exposed under `/product/inbound-emails`. Versioned automation preview, activation, runs, rollback preview, and rollback use `/product/automation-*`. Export preparations snapshot receipt versions and validation; `POST /product/export-commands` requires `Idempotency-Key`, warning acknowledgements, and rejects stale preparations. The workspace provides loading, empty, error, disabled, success, and retry states for these workflows.
