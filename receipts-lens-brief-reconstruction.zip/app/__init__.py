"""ReceiptLens application package."""
