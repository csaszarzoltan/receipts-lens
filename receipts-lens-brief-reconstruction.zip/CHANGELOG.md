# Changelog

## [Unreleased] - 2026-08-26 (Google SSO + tartós session — G1-G5, t_3945fe93)

### Added
- **Google SSO (OAuth 2.0 authorization-code)** — `docs/plans/google-sso-2026-08-26.md` G1-G5:
  - Backend `app/google_oidc.py` — id_token RS256 ellenőrzés (issuer/audience/nonce/email_verified, JWKS, `exp`/`iat` ablak).
  - Routes `app/auth_api.py` — `GET /api/auth/google/status` (`{enabled}` probe, dual `/auth` + `/api/auth` prefix a prod Caddy-hoz), `GET /api/auth/google/start` (state+nonce 32B random, `HttpOnly+Secure+SameSite=Lax` cookie 10 perc, `return_to` csak `/`-rel prefixelt lehet), `GET /api/auth/google/callback` (CSRF-ellenőrzés + `exchange_google_code` + `find_or_create_household_owner` + `create_session` → `302 #session_token=&expires_at=&return_to=`). Hiányzó konfigra `503 Google sign-in is not configured`. `POST /api/auth/session/logout` (`204` idempotens, Bearer nélkül `401`) dual prefixen.
  - `app/product_service.py` — `SESSION_TTL` 30 → **180 nap**, `resolve_session` sliding (minden hitelesített hívás `expires_at = now + TTL`), `delete_session`, `find_or_create_household_owner`.
  - Frontend `frontend/app/auth/google/callback/page.tsx` — fragment `#session_token&expires_at&return_to` parse → `setSessionToken` → `/dashboard` (query fallback, open-redirect guard); `frontend/lib/api.ts` — `googleSsoEnabled()`, `logoutSession()`; `frontend/app/(auth)/login/page.tsx` — „Folytatás Google-lel" gomb `status` probe alapján; `frontend/components/Topbar.tsx` — „Kilépés" gomb (`logoutSession` + `localStorage` törlés + `/login`).
  - Env: `RECEIPTLENS_GOOGLE_CLIENT_ID` / `_SECRET` / `_REDIRECT_URI` (+ `_OAUTH_STATE_SECRET`, `_AUTH_BASE_URL`); új Python függőség nincs (`cryptography` + `httpx` már bent).
- **PROD E2E `frontend/e2e/prod-journey.spec.ts`** bővítés — `login: Google SSO gomb látszik (enabled:true → Folytatás Google-lel)` (status probe conditional), `auth/google/callback: fragment nélkül hibaüzenet (nem crash)`, `tartós login: /auth/session/logout` (401/204/idempotens + sliding perzisztencia), `auth/magic-link: oldal betölt + űrlap` (F1.3 regression, magic-link továbbra is él), `logout UI: session nélkül product/* 401 + login oldal látható` (auth-gating + Google SSO + magic-link ellenőrzés session nélkül). Teljes suite `npx playwright test --config playwright.prod.config.ts` zölden élesben (`https://receipts.allthezoo.com`).

### Changed
- README: Google SSO + tartós bejelentkezés/Kilépés feature blokkok, magic-link megjegyzés, env-var táblázat kiegészítése (`GOOGLE_*`, `OAUTH_STATE_SECRET`, `AUTH_BASE_URL`).

### Verification
- 79 új tesztek összesen (`tests/test_google_auth_routes.py`, `tests/test_session_sliding.py`, `frontend/e2e/prod-journey.spec.ts` 25 → 27 — ebből 2 új a G5-ben: magic-link + logout UI flow; a korábbi d740103 commit 3 G5-előfutár tesztet már landolt).

## [Unreleased] - 2026-08-13 (F1.3 auth review fixes — t_313a4ac0)

### Fixed
- **CRITICAL-1 (account takeover)**: `POST /auth/magic-link-request` no longer accepts/honors a caller-supplied `household_id` — a magic link can never mint an owner session for an arbitrary household. A fresh household is always derived from the email at verify time; joining an existing household requires the owner-issued invite flow.
- **CRITICAL-2**: legacy `X-Role` dev headers map to RESTRICTED household roles (`admin`→`adult`, `reviewer`→`adult`, `integrator`→`child`) — the demo header auth no longer grants owner-equivalent power (invite/member management stays owner-only).
- **HIGH-3**: every mutating `/product` endpoint is now write-gated (`child`/`view_only` get `403`): upload, metadata PUT, connections POST, approval request, job retry/cancel, line-items PUT, exports/export-runs/export-commands, saved-views, notifications, automation-rules (+preview/activate/runs), duplicates decision, preferences, inbound emails, approval-flows, recurring feedback, exchange-rates, currency convert, permissions, quality benchmarks/profiles, rollbacks, QBO oauth start/refresh/disconnect/mappings, provider-mappings validate, accounting-projection refresh.
- **HIGH-4**: `PATCH /product/receipts/{id}/workspace` now allows `owner`/`adult` (was admin/reviewer only); `child`/`view_only` stay blocked with `403`.
- **HIGH-5**: the invite email link now embeds the ids the accept page requires — `{base}/auth/invite?token=...&household={household_id}&invite={invite_id}`.
- **MED-6**: invite accept validates the household+invite path BEFORE consuming the token, so a wrong path no longer burns a valid invite token.
- **MED-7**: `_is_production` became `is_production()` — the env is re-read per request instead of at import time.
- **LOW-8**: `add_member` no longer rejects household roles via the stale second role check (owner-managed households can roster `adult`/`child`/`view_only` members).

## [Unreleased] - 2026-08-13 (US-024 household auth F1.3)

### Added
- US-024: password-less household auth (F1.3 of `docs/plans/consumer-pivot-2026-08-13.md` §2.3):
  - Magic-link login: `POST /auth/magic-link-request` creates a single-use, 15-minute token
    (sha256-hashed at rest); `POST /auth/magic-link-verify` consumes it and issues a 30-day
    session. Dev mode (`RECEIPTLENS_ENV != production`) returns the link in the API response;
    production never leaks the raw token. Email delivery reuses the existing
    `send_email_notification()` SMTP channel (`RECEIPTLENS_SMTP_HOST` +
    `RECEIPTLENS_SMTP_ENABLED=1`).
  - Family invites: the household owner invites members by email with a household role
    (`adult` / `child` / `view_only`); 7-day single-use tokens; accept creates the membership
    and signs the user in (`POST /auth/households/{id}/invites[/{invite_id}/accept]`).
  - Role gates: `child` / `view_only` get `403` on receipt edits (`PATCH /product/review-items`),
    the receipt workspace (`PATCH /product/receipts/{id}/workspace`) and invite creation;
    `owner`/`adult` may edit; only the owner can invite. (Hardened in the F1.3 review-fix
    pass: header roles are restricted and every mutating `/product` endpoint is write-gated.)
  - Sessions travel as `Authorization: Bearer <session_token>`; the legacy `X-Tenant-ID` /
    `X-Role` headers remain valid in development only and are rejected in production (AC6).
  - Frontend: `/auth/magic-link` + `/auth/invite` pages, session persistence in
    `lib/auth.ts`, invite UI on the members page, magic-link entry on the login page.
- Docs: `docs/api.md` "Household auth (F1.3, US-024)" section.

### Verification
- New contract suite `tests/test_us_024_auth_contract.py` — 25 tests (single-use, expiry 401,
  owner-only invites, 403 role gates, dev-header compat), exercised through a real FastAPI
  TestClient (HTTP-level, no mocks); extended to 31 tests with the F1.3 review regressions
  (magic-link household binding, invite-link ids, accept token reuse, workspace role gates,
  write-gate matrix, add_member household roles).
- Frontend `tsc --noEmit`: 0 errors.
- Full Python regression: 1424 passed / 10 skipped (+1 documented pre-existing flake in
  `test_fetcher_wiring.py`, untouched by this change).

## [Unreleased] - 2026-08-13 (US-019 consumer pivot F1.1)

### Added
- US-019: consumer-pivot navigation & role naming (F1.1 of `docs/plans/consumer-pivot-2026-08-13.md`):
  - Household navigation labels (`lib/nav.ts`): Vásárlások, Nyugta hozzáadása, Ellenőrzés,
    Háztartási keret, Előfizetések, Előrejelzés, Összesítés, Családi postafiók, Ismétlődések —
    zero business jargon in the main navigation.
  - Business features (Approvals, Export Center, Accounting, Integrations, Automations) are
    **hidden, not deleted** — grouped behind a separate collapsible "Business" section in the
    desktop sidebar and a "Business" sub-heading in the mobile slide-over (separate entry point).
  - Household role naming (`lib/roles.ts`): admin → Háztartás tulajdonosa, reviewer → Felnőtt tag,
    integrator → Könyvelő / tanácsadó (Business mód); target-state roles (Gyermek / korlátozott tag,
    Csak megtekintés) carried as vocabulary for F1.3.
  - Role surfaces (login, onboarding, topbar, members, permissions) display household labels;
    tenant selector removed from the consumer topbar; tenant wording replaced with Háztartás.
  - Consumer page sweep: receipt detail no longer shows cost-center input or export-readiness panel
    (business surface), Reports page no longer shows export activity, inbox shows Családi postafiók,
    status badges use household labels. Wire format untouched (backend schema unchanged).

### Verification
- Frontend `tsc --noEmit`: 0 errors; `next build` passes.
- New BDD contract `tests/test_us_019_consumer_navigation.py` (5 tests) locks the nav/role mapping.
- Full Python regression: 1342 passed / 10 skipped (unchanged).

## [Unreleased] - 2026-08-11 (BUG-007/008/010 fixes)

### Fixed
- BUG-007: dashboard loaded empty after sign-in — the CORS allowlist defaulted to ports 3000 only, blocking the Playwright E2E stack (frontend on port 3010) with no `Access-Control-Allow-Origin` header, so every dashboard fetch failed in the browser. Ports 3010 are now part of the development default origin list (`http://localhost:3010` / `http://127.0.0.1:3010`).
- BUG-008: `POST /product/automation-rules` returned a bare `422 invalid rule` for unsupported keys. The error now names the offending condition/action key(s) and lists the supported sets, e.g. `invalid rule: unsupported condition key(s) ['bad_key']; supported conditions are [...]`. Blank names return `invalid rule: name is required`.
- `AdvancedWorkspace.exports` no longer crashes on databases where the workflow `export_commands` table has not been created (fresh/in-memory stores) — the workflow-run listing is skipped defensively.

### Added
- BUG-010: `docs/api.md` now has dedicated sections for `/product/connections` (GET/POST/test), `/product/automation-rules` (GET/POST/preview, supported condition/action keys, documented 422 messages), and `/product/export-runs` (GET/POST, `{run_id}`, `{run_id}/artifact`) with request/response examples.

### Verification
- Full Python regression 1282 passed / 10 skipped.
- New tests: `test_create_rule_rejects_unsupported_keys_with_specific_message`, `test_automation_rule_422_names_unsupported_keys`, `test_api_docs_cover_connections_automation_rules_and_export_runs`, CORS port-3010 assertions in `test_security_cors_allowlist_and_csv_formula`.
- Ruff: no new errors on changed files (pre-existing 21 baseline unchanged).
- Frontend `tsc --noEmit` passes; live browser verification: dashboard loads with service status + KPI cards after sign-in; dashboard reflects uploaded receipts.

## [Unreleased - Connected workflow completion] - 2026-08-11

### Added
- Tenant-scoped provider connection list/detail, credential-purging disconnect, and immutable mapping current/save APIs.
- QuickBooks Online provider-domain foundation with tenant-bound OAuth state, AES-GCM credential storage, immutable mapping versions, replay-safe export items, and reconciliation.
- Decimal source-currency, dated-rate, tax-arithmetic, and deterministic payload-preview services.
- BDD-derived US-010 through US-018 regression coverage and a polished QuickBooks sandbox onboarding panel.
- Live QuickBooks Online OAuth callback (`/product/connections/quickbooks/oauth/callback`) completing the Intuit code→token exchange with tenant-scoped single-use state validation (state checked before any exchange; `502 oauth_exchange_failed` when Intuit rejects; `422 oauth_state_invalid` otherwise).
- Expiry-aware token refresh (`POST /product/connections/{id}/refresh`) with 5-minute refresh margin; failures flip the connection to `reauthorization_required` and return `409`.
- RFC 7636 S256 PKCE wired end-to-end: `start_oauth` stores a code verifier and returns a derived challenge; the callback exchange sends the verifier to Intuit. The authorize URL cannot be replayed against the token endpoint.
- Best-effort Intuit token revoke on disconnect (revoke failure does not block local disconnect).
- Integration detail screen (`/integrations/[id]`) with connection health, refresh/disconnect actions, and export run history.

### Changed
- OAuth client credentials are config-driven (`RECEIPTLENS_QBO_CLIENT_ID` / `RECEIPTLENS_QBO_CLIENT_SECRET`); unset secret fails fast instead of leaking a placeholder.

### Verification
- Full Python regression 1303 passed / 10 skipped (was 1293 / 10), including 10 new live-callback/refresh/revoke tests with a recording httpx transport.
- Ruff clean on changed files (only the pre-existing B008 FastAPI default-argument pattern remains).
- Frontend `tsc --noEmit` passes with the new integration detail screen.


## [Unreleased] - 2026-08-11

### Added
- Acceptance-backed exception-to-export workflow for US-001 through US-009, including confidence triage, provenance, immutable export preparation, idempotent commands, attachment-level inbox processing, benchmark profiles, safe automation previews, run history, and rollback.
- Repository lab gates for TDD, BDD structure, security regression, documentation sync, UI build verification, and git push verification.
- API acceptance tests for invalid confidence fields, tenant-scoped quality profiles, and required export idempotency keys.

### Verification
- Full Python regression, focused BDD/API tests, frontend type-check and production build, startup smoke checks, security tests, and ZIP integrity verification are recorded in `development-report.md`.


All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.4.0] - 2026-08-01

### Features

- **Multi-language OCR** — language detection via Tesseract script analysis, locale-aware date parsing (DE, FR, ES, IT, HU, EN), locale-sensitive currency extraction with `_CURRENCY_LOCALE_HINTS` fallback, 6 supported languages (eng, deu, fra, spa, ita, hun).
- **Batch processing** — `BatchProcessor` with `ThreadPoolExecutor` for parallel receipt processing, `BatchJob` model with job lifecycle (pending → running → completed/failed), async batch API endpoint (`POST /api/v1/receipts/batch`), job status polling (`GET /api/v1/receipts/batch/{job_id}`).
- **Accounting export** — `ReceiptExporter` with `ExportProfile` for QuickBooks, Xero, and Generic CSV formats, column mappings per software, CSV formula injection prevention (`_neutralize_csv()`), export API endpoint (`GET /api/v1/receipts/export/{format}`).
- **Receipt normalization** — `NormalizedReceipt` Pydantic schema with `normalize_date()`, `normalize_currency()`, `normalize_receipt()` for cross-border expense intelligence.
- **API v2 endpoints** — batch processing and export endpoints wired into FastAPI with full OpenAPI schemas.
- **CLI subcommands** — `python -m app.cli batch`, `python -m app.cli export`, `python -m app.cli info` for command-line batch processing and export.

### Fixes

- **SyntaxError in product_service.py** — extracted `rid = row["receipt_id"]` to fix nested f-string quotes breaking Python 3.11.
- **Test regressions in test_ocr_coverage.py** — updated `test_no_currency` and `test_empty_text` to match locale fallback behavior (returns "USD" instead of None).

### Tests

- 60+ new tests across 6 test modules: `test_multilang_ocr.py`, `test_normalization.py`, `test_batch_processor.py`, `test_export_profiles.py`, `test_api_v2.py`, `test_cli.py`.
- Full regression suite: 805 passed, 7 skipped, 1 pre-existing TDD stub. 44 test files collected.
- Ruff: 155 pre-existing violations, 0 new.

### Docs

- Created `docs/multi-language-guide.md` — supported languages, Tesseract setup, accuracy tips per language.
- Created `docs/accounting-export-guide.md` — QuickBooks/Xero/Generic CSV formats, column mappings, import instructions.
- Updated `docs/api.md` — batch and export endpoint schemas with request/response examples.
- Updated `README.md` — multi-language OCR, batch processing, accounting export features added.

## Unreleased

### Forecast
- **Forecast engine** — next-period spend forecasting with per-category and overall predictions using trailing moving average + linear trend extrapolation, confidence bounds (±1.96× residual std), and an injectable LLM narrative seam.
- **Anomaly detection** — flag category-period spend deviations via z-score or MAD (median absolute deviation) with leave-one-out baselines.
- **Budget variance projection** — project each budget's end-of-period spend from the current period's run rate and report expected overage with on_track / warning / over_budget status.
- **REST endpoints** — `GET /forecasts` (overall + per-category forecast), `GET /forecasts/anomalies` (detected spending anomalies), `GET /forecasts/budget-variance` (projected budget overage).
- **Dashboard** — server-rendered forecast dashboard at `GET /dashboard` with inline SVG bar chart, per-category forecast cards, flagged anomalies table, and budget variance table. No JavaScript or remote assets.
- **CLI** — `receipts-lens forecast --period monthly` outputs next-period spend, confidence bounds, and trend per category.
- 78 forecast tests added (ForecastEngine, AnomalyDetector, BudgetVarianceProjector, REST routes, CLI). Full suite: 884 passed, 7 skipped, 0 failed.

### Product workflows
- Added a responsive receipt upload workspace at `/workspace`.
- Added tenant-scoped receipt history, retry, cancellation, review, and optimistic correction workflows.
- Added team membership, role checks, and one-time API key creation with digest-only storage.
- Added accounting connection metadata, mapping validation, export records, and a trust dashboard.
- Added a SQLite-backed application service with optional persistent storage through `RECEIPTLENS_PRODUCT_DB`.
- Added end-to-end and negative tests for all six product research requirements.



### Homepage
- Added a responsive, self-contained Hungarian landing page at `GET /`.
- Added direct Swagger UI, ReDoc and health links, supported-operation summaries and a Windows upload example.
- Added deterministic homepage, navigation and metadata-escaping tests.



### Research requirements
- Added a durable tenant-scoped SQLite reference data plane with job leases, idempotency, optimistic locking and transactional outbox.
- Added authentication, RBAC, quota, signed webhook and tamper-evident audit primitives.
- Added deterministic OCR benchmark, calibration, review and correction provenance services.
- Added accounting connector and usage-metering ports plus readiness/capability endpoints.



### Subscription alerts
- **Renewal tracking** — `extract_next_renewal_date()` computes the next renewal from a last-known date and recurrence frequency (monthly / quarterly / annual), rolling forward to the first date on or after today with day-of-month clamping for short months (Jan 31 → Feb 28).
- **Price-increase detection** — `detect_price_increase()` flags a subscription when the most recent charge exceeds the rolling average of prior charges by more than a configurable threshold (default 10 %).
- **Cancellation guides** — `CancelGuide` with curated steps + account links for 22 merchant entries across 21 distinct brands (Netflix, Spotify, Disney+, Amazon Prime, Max/HBO Max, Hulu, Audible, YouTube Premium, Microsoft 365, Adobe, ChatGPT, Apple Music/TV+/iCloud+, Dropbox, Google One, Notion, Figma, Canva, Headspace, Crunchyroll) and a generic fallback for unknown merchants.
- **REST endpoints** — `GET /api/v1/subscriptions` (active subscriptions with renewal date, monthly cost, annualized spend, trend) and `GET /api/v1/subscriptions/{id}/cancel-guide` (merchant-specific steps; deterministic merchant resolution for unresolvable ids, generic fallback otherwise). Mounted via the router in `app/subscriptions_api.py`.
- **Trend-data endpoint** — `GET /api/v1/subscriptions/trend-data` returns time-series spending data (monthly / quarterly / annual granularity), annual total, average monthly spend, and trend direction (increasing / decreasing / stable).
- **Renewal-timeline endpoint** — `GET /api/v1/subscriptions/renewal-timeline` returns upcoming renewals sorted by date with a `days_until` countdown per subscription.
- **Email-alert toggle** — `POST /api/v1/subscriptions/{id}/email-alert` and `GET /api/v1/subscriptions/{id}/email-alert` toggle and read back per-subscription email alert preferences (in-memory, per-process). The POST endpoint validates `sub-NNN` format and returns 404 for invalid ids.
- **Daily scheduler** — `daily_scheduler()` scans all tracked subscriptions and fires renewal alerts (within 7-day window) and price-hike alerts via SMTP. Handles SMTP failures gracefully per-subscription, falls back to `DEMO_SUBSCRIPTIONS` when the accounting workspace is empty.
- **Email notifications** — `send_email_notification()` delivers renewal/price alerts via SMTP when a config dict is provided; delivery additionally requires `RECEIPTLENS_SMTP_ENABLED=1` (env gate — the process never dials out implicitly). No config / no host / gate off → returns `False` silently.
- **Alert types** — `SUBSCRIPTION_RENEWAL` (info) and `PRICE_INCREASE` (warning) added to `AlertStore`, with `schedule_renewal_alerts()` (fires N days before renewal, default 3) and `create_price_increase_alert()`.
- **Subscriptions dashboard** — inline SVG trend chart with direction badge (`↑` / `→` / `↓`), urgency-colored renewal timeline with countdown badges, and per-subscription email alert toggle switches in the workspace UI. Data sourced from `GET /subscriptions/trend-data` and `GET /subscriptions/renewal-timeline`.
- **Subscriptions UI** — new Subscriptions page (`frontend/app/(app)/subscriptions/page.tsx`): summary cards (count, monthly total), upcoming renewals within 14 days, price-change cards, full table with trend indicators, cancel-guide modal, and a persisted Email alerts toggle through `PUT /product/preferences` (`email_alerts` key).
- Only new runtime dependencies: none — implementation uses the existing stdlib + FastAPI stack (all deps already pinned in `pyproject.toml`).

### Subscription intelligence docs
- Updated `docs/subscription-alerts.md` — added daily scheduler section, trend-data / renewal-timeline / email-alert endpoint documentation, updated Python API examples with `daily_scheduler`, updated Subscriptions UI section with trend chart and renewal timeline.
- Updated `docs/api.md` — added trend-data, renewal-timeline, and email-alert (POST/GET) endpoint documentation with request/response schemas and field tables.
- Updated `README.md` — expanded subscription intelligence feature description to cover daily scheduler, trend dashboard, renewal timeline, email toggle, and all six endpoints; updated test count (1266 total, 1256 passed).

### AI Vision OCR
- **LLM vision extraction** — `VisionOcrProvider` sends the receipt image (base64 data URL, MIME sniffed from magic bytes) to an OpenAI-compatible vision chat-completions endpoint and returns structured receipt JSON; model asked for `merchant` / `date` / `total` / `tax` / `currency` / `line_items` with `temperature: 0.0`.
- **Automatic Tesseract fallback** — `parse_receipt_with_vision()` returns the same `ConfidenceReceipt` shape as the classic pipeline; the producing path is marked via `confidence["source"]` (`"vision"` | `"tesseract"`). Fallback when disabled / no API key / timeout / API error / non-JSON response (one retry for transient failures: timeout, connection error, HTTP 5xx).
- **Cost guard** — vision path is OFF by default: requires `VISION_OCR_ENABLED` (1/true/yes/on) AND `LLM_API_KEY`. Config mirrors `app/categorizer.py`: `LLM_API_KEY` / `LLM_BASE_URL` (default `https://api.openai.com/v1`) / `LLM_MODEL` (default `gpt-4o-mini`), plus `VISION_OCR_TIMEOUT` (default 30.0 s).
- **AI-mode API fields** — `ai_scan=true` form field on `POST /v1/parse-receipt` and `POST /product/receipts/upload` exposes top-level `source` plus `ai_result` / `tesseract_result` payloads (both pipelines on the same image); regular flow unchanged (no breaking changes). Batch/export endpoints intentionally keep the classic path.
- **Frontend AI Scan** — accessible `AiScanToggle` (role=switch) in the upload flow, `AiResultPanel` with source badge, per-field confidence and friendly Tesseract fallback notice, `uploadReceiptWithAi()` client, and a contract-shaped dev mock behind `NEXT_PUBLIC_USE_MOCK_AI=1`.
- Only new runtime dependency: `httpx>=0.27` (pinned in `pyproject.toml`).

### Fixed
- Replaced placeholder receipt create/list/get endpoints with working in-memory implementations.
- Made `ReceiptStore.get()` lock-protected and added a stable `list_all()` snapshot API.

### Tests and documentation
- Added receipt CRUD runtime acceptance tests.
- Added a tested Hungarian Windows installation and usage guide.
- 69 new vision-OCR tests: `test_vision_ocr.py` (29, provider + fallback chain), `test_api_vision.py` (9, AI-mode API contract), `test_frontend_ai_scan.py` (31, AI Scan UI interface + behavior). Full suite: 1157 passed, 7 skipped, 0 failed across 50 modules; Ruff 0 new rule-level errors vs the pre-feature baseline.
- Added `docs/ai-vision-ocr.md` — AI Scan setup (env vars, cost guard), fallback chain, API response shapes, Python library usage, frontend behavior.
- Updated `README.md` (AI Vision OCR feature, AI Scan getting-started setup, env-var table, docs list) and `docs/api.md` (AI-mode `ai_scan=true` section on `POST /v1/parse-receipt`).

## [0.6.0] - 2026-07-25

### Features

- **AI categorization** — `Categorizer` class with GPT-4o-mini prompt-based classification of receipts into categories (groceries, dining, transport, utilities, entertainment, health, shopping, income, other). Consistent label taxonomy with confidence scoring.
- **Spending analytics** — `AnalyticsService` with spending trends over time, category breakdowns, top merchants report, monthly/yearly comparisons, and spending forecasts.
- **Budget management** — `BudgetStore` with per-category monthly budget tracking, spending vs. budget comparisons, and remaining budget calculations. Fixed double-counting bug in `_recompute()`.
- **Alerting system** — `AlertManager` with configurable threshold-based notifications per category. Tracks alert history and supports percentage-based or absolute thresholds.
- **API integration** — all new modules wired into FastAPI layer (`app/api.py`) with full endpoint coverage.

### Fixes

- **Dependency fix** — added `reportlab>=4.0` to project dependencies for PDF report generation support.

### Tests

- 4 new test modules: `test_categorize.py`, `test_analytics.py`, `test_budgets.py`, `test_alerts.py` — comprehensive coverage for all new features.
- Full regression suite: 501 passing, 7 skipped, 0 failed. Ruff clean.

## [0.5.0] - 2026-07-24

### Features

- **OCR pipeline overhaul** — 7-stage image preprocessing (EXIF rotation, deskew, adaptive threshold via integral image, upscale, contrast, sharpen) for robust real-world receipt scanning.
- **Magic byte validation** — validates JPEG/PNG/TIFF/BMP/WEBP/GIF headers before processing (SSRF hardening).
- **Typed exception hierarchy** — `OCRError` → `InvalidImageError`, `UnsupportedImageFormatError`, `CorruptImageError` for precise error handling.
- **Railway deployment** — production Dockerfile with Tesseract system deps, `railway.toml` config, health check, and restart policy. Live at https://receiptslens-production.up.railway.app.
- **Cloud deployment config** — production-ready Dockerfile + deployment configuration.

### Fixes

- **CSV formula injection** — `_neutralize_csv()` prefixes `=`, `+`, `-`, `@` characters with a single quote to prevent spreadsheet formula injection in generated reports.
- **Adaptive threshold O(n²) → O(n)** — replaced nested-loop implementation with integral image (summed area table), cutting 240K-pixel OCR from >20s to <1s.
- **SSRF guard** — added hostname validation to `validate_image_url` for additional SSRF protection.
- **PORT expansion** — `startCommand` wrapped in `sh -c` for proper `$PORT` environment variable expansion on Railway.

### Tests

- 4 new test modules: `test_magic_bytes.py` (167 lines), `test_ocr_coverage.py` (436 lines), `test_ocr_exceptions.py` (151 lines), `test_preprocessing.py` (311 lines) — 1065 lines of new test coverage.
- `test_reports.py` expanded with CSV injection regression tests (718 lines added).
- Full regression suite: 415 passing, 7 skipped, 0 failed. Ruff clean.

### Docs

- Added `docs/ocr-pipeline.md` architecture documentation.
- Updated README with library usage and Railway deployment section (live URL, Docker self-host, env vars, usage examples).
- Added `examples/parse_receipt.py` runnable CLI demo.

## [0.4.0] - 2026-07-20

### Features

- Add non-blocking async image fetch with `app/ssrf_guard.py` — SSRF-safe URL validation with egress allowlist, redirect handling, and configurable `MAX_IMAGE_BYTES` / `URL_FETCH_TIMEOUT` limits.
- Add duplicate receipt detection endpoint `POST /v1/check-duplicates` with vendor similarity scoring and canonical total comparison.
- Add `POST /v1/parse-receipt/image-url` endpoint for parsing receipts from remote URLs with SSRF protection.
- Configurable resource limits: `MAX_IMAGE_BYTES` and `URL_FETCH_TIMEOUT` constants replace hardcoded values.

### Tests

- 211 tests passing (up from 29 in v0.2.0). Full regression suite covers SSRF guard, async fetch, image URL endpoint, duplicate detection, configurable limits, and security egress allowlist.

## [0.3.0] - 2026-07-20

### Features

- Add batch receipt processing endpoints:
  - `POST /v1/parse-receipts` for synchronous batch parsing from multipart `files[]` uploads or JSON `image_urls`.
  - `POST /v1/parse-receipts/async` for asynchronous batch jobs with optional `webhook_url` delivery.
- Batch results preserve input order via `index`, return per-item errors without failing the whole request, and include `summary.total`, `summary.successful`, and `summary.failed`.
- Input validation now rejects mixed `files[]` and `image_urls` with `400`, empty requests with `422`, and more than 20 inputs with `413`.

### Tests

- Added `tests/test_batch_processing.py` covering batch route registration, mixed-input rejection, payload-size limits, empty-image behavior, URL fetch error handling, and summary count correctness.
- Full regression suite still passes against existing single-receipt endpoints and async confidence workflows.

## [0.2.0] - 2026-07-20

### Features

- Add per-field confidence scores to receipt parsing responses. Each field
  (`vendor`, `total`, `date`, `tax`, `currency`, `line_items`) now includes
  a `confidence` float between 0.0 and 1.0 derived from Tesseract
  `image_to_data` accuracy metrics.
- Add `POST /v1/parse-receipt/async` for non-blocking OCR jobs. Accepts
  optional `webhook_url` to receive a JSON POST on completion or failure.
- Add `GET /v1/jobs/{job_id}` for polling async job status and results.
- Run blocking OCR calls inside a ThreadPoolExecutor to keep the FastAPI
  event loop responsive.

### Tests

- Added `tests/test_async_confidence.py` with 10 interface and behavioral
  tests covering async scheduling, confidence schema, webhook delivery, and
  job polling. Full suite is 29 tests passing.

## [0.1.1] - 2026-07-20

### Fixed

- **P0 crash on real receipts.** `_parse_line_items` raised `IndexError: no such group`
  because the line-item regex had a non-capturing price group. The endpoint now returns
  `200` with the full schema on any receipt that contains line items. Regression tests
  added in `tests/test_ocr.py` and `tests/test_api.py`.
- Moved `import io` to the top of `app/ocr.py` (it was lazily imported at module bottom).
- Added `infra/` scaffold (Dockerfile + README) that was missing from the v0.1.0 build.

## [0.1.0] - 2026-07-20

### Features

- Initial ReceiptLens OCR API scaffold.
- `POST /v1/parse-receipt` endpoint accepts multipart file upload or `image_url` form field.
- Tesseract 5 OCR pipeline with image pre-processing (grayscale, upscale, contrast, sharpen).
- Regex-based receipt parser extracting vendor, date, line items, tax, total, and currency.
- Async FastAPI application with `/health` endpoint and OpenAPI docs.
- Pydantic-style response schema: `vendor`, `total`, `date`, `tax`, `currency`, `line_items[]`.

### Tests

- 19 pytest tests covering API routes, OCR signatures, runtime behavior, and regression cases.
- `ruff` linting configured and passing.

## 1.1.1 - 2026-08-01

### Added
- Tenant-scoped, role-aware daily work queue for failed jobs, OCR review, and approvals.
- Atomic receipt workspace update covering fields, line items, metadata, status, version, job status, and audit.
- TDD acceptance tests for workflow ordering, transaction rollback, concurrency, and API behavior.
- Delivery requirements and implementation report.

### Changed
- Dashboard next actions now use the prioritized work queue.
- Review save now performs one atomic workspace request instead of separate receipt and metadata requests.

## 1.2.0 - 2026-08-01

### Added
- Early accounting-readiness state and stable issue details on product receipt queries.
- Receipt-list filtering by blocked, warning, or exportable state.
- Export-blocker tasks in the prioritized daily work queue.
- Accounting-readiness badges and filter controls in the receipt workspace.
- TDD acceptance tests for readiness state, filtering, API behavior, queue behavior, and UI contracts.
- Product/UX analysis and full implementation delivery report in `docs/`.

### Changed
- Receipt filter reset now clears both inputs and select controls.
- Receipt table now surfaces accounting state before users enter export preparation.

## 1.3.0 - 2026-08-01

### Added
- Precise work-queue deep links for review receipts, export blockers, and approval tasks.
- Accessible contextual dialogs for approval decisions, API-key creation, saved-view naming, and retention purge.
- Inline dialog validation, mandatory rejection reasons, and typed confirmation for irreversible purge.
- TDD acceptance coverage for deep links and business-action dialog contracts.
- Updated product analysis, requirements, GUI, API, workflow, accounting-readiness, delivery, and GitHub README documentation.

### Changed
- Dashboard actions retain complete task URLs and navigate to exact records and fields.
- Saved views now preserve the accounting-readiness filter.
- Approval cards can receive programmatic focus after task navigation.

### Removed
- Browser-native business `prompt()` and `confirm()` flows for approval, API-key, saved-view, and purge actions.

## [1.5.0] - 2026-08-10

### Added
- Confidence-filtered review queue with deterministic pagination and sorting.
- Immutable export preparations, tenant-scoped idempotent export commands, run detail, and CSV artifacts.
- Persisted OCR benchmark reports and versioned confidence threshold profiles.
- Versioned automation preview, activation, run history, optimistic rollback preview, and rollback.
- Redacted receipt audit endpoint and nine BDD story regression tests.

### Changed
- Export preparation now snapshots receipt versions and validation results.
- Direct async API tests run in minimal CI without an external pytest async plugin.
- README now provides a concise GitHub product overview and primary workflow.

### Fixed
- API v2 direct-call defaults and the previously failing async endpoint behavioral tests.
- Export preparation inserts remain compatible after additive schema migration.

### Tests and documentation
- Added US-001 through US-009 behavior coverage and updated API/workflow documentation.

## [1.6.0] - 2026-08-10

### Added
- Durable inbound-email attachment records with persisted bytes, SHA-256, sanitized names, MIME/magic validation, quarantine, retries, and derived parent status.
- Field-level automation conflict detection with deterministic priority, creation-time, and rule-ID tie breaking.
- Export run, quality calibration, automation preview/history/rollback, and detailed Inbox Next.js screens.
- Cross-tenant and atomic rollback regression tests.

### Security
- Replaced wildcard credentialed CORS with `RECEIPTLENS_ALLOWED_ORIGINS`; localhost origins remain the development default.
- Preserved CSV formula neutralization and tenant-scoped lookup behavior.

### Verification
- Full Python regression and changed-module coverage completed; frontend type-check, production build, and backend startup passed.
- Browser E2E/screenshots, Hermes gates, full-repository Ruff cleanup, and git push remain environment/repository blockers documented in `development-report.md`.
